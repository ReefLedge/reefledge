from typing import Final
import os
import datetime
import pathlib

THIS_DIRECTORY_NAME: Final[str] = os.path.abspath(os.path.dirname(__file__))


def conditionally_clean_up_pickle_files(
    target_directory_name: str = THIS_DIRECTORY_NAME) -> None:
    ####################################################################
    file_name: str
    for file_name in os.listdir(target_directory_name):
        if _is_pickle_file(file_name):
            file_path = os.path.join(target_directory_name, file_name)

            if _is_file_too_old(file_path):
                os.remove(file_path)

def _is_pickle_file(file_name: str) -> bool:
    return file_name.split('.')[-1] in ('pickle', 'pkl')

def _is_file_too_old(file_path: str) -> bool:
    file_creation_datetime = __lookup_file_creation_datetime(file_path)
    threshold = datetime.datetime.now() - datetime.timedelta(weeks=1)

    return (file_creation_datetime < threshold)

def __lookup_file_creation_datetime(file_path: str) -> datetime.datetime:
    my_file = pathlib.Path(file_path)
    my_timestamp: float = my_file.stat().st_ctime
    file_creation_datetime = datetime.datetime.fromtimestamp(my_timestamp)

    return file_creation_datetime
